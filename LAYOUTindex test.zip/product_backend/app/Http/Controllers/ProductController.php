<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function create(Request $request){
        DB::table('products')->insert([
            'name'=>$request->name,
            'subcategory_id'=>$request->subcategory
        ]);
        return "Created a new product successfully";
    }

    public function get(){
        $products=DB::table('products as p')
            ->join('subcategories as s','s.id','p.subcategory_id')
            ->select([
                'p.id as pro_id',
                'p.name as name',
                's.id as sub_id',
                's.name as subcategory'
            ])
            ->get();
        return $products;
    }

    public function getProduct($id){
        $product=DB::table('products')
            ->where('id',$id)
            ->get();
        return $product;
    }

    public function update(Request $request){
        $name='';
        $subcat='';
        foreach ($request->data as $d) {
            if($d['name']=='product'){
                $name=$d['value'];
            }
            elseif($d['name']=='subcategory_id'){
                $subcat=$d['value'];
            }
        }
        DB::table('products')
            ->where('id', $request->id)
            ->update([
                'name' => $name,
                'subcategory_id'=>$subcat
            ]);
        return "Updated product successfully";
    }

    public function delete($id){
        DB::table('products')
            ->where('id',$id)
            ->delete();
        return "Deleted product successfully";
    }
}
