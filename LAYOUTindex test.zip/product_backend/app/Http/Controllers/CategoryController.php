<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Category;
use App\Models\Subcategory;

class CategoryController extends Controller
{
    public function getCategories(){
        $categories=Category::with('subcategories')->get();
        $categories=$categories->map(function ($c){
            $subcat=$c->subcategories->map(function($s){
                return $s->name;
            })->toArray();
            $subcategories=(count($subcat)>0)?implode(',',$subcat):[];
            return [
                'id'=> $c->id,
                'name'=> $c->name,
                'subcategories'=>$subcategories
            ];
        });
        return $categories;
    }

    public function getCategory($id){
        $category=Category::with('subcategories')->where('id',$id)->get();
        return $category;
    }

    public function getSubategories(){
        $subcategories=DB::table('subcategories as s')
            ->join('categories as c','c.id','s.category_id')
            ->select([
                's.id as id',
                's.name as name',
                'c.id as cat_id',
                'c.name as category'
            ])
            ->get();
        return $subcategories;
    }

    public function create(Request $request){
        $id=DB::table('categories')->insertGetId([
            'name'=>$request->name
        ]);
        $subcategories=explode(',',$request->subcategories);
        foreach ($subcategories as $s) {
            DB::table('subcategories')->insert([
                'name'=>$s,
                'category_id'=>$id
            ]);
        }
        return "Created a new category successfully";
    }

    public function update(Request $request){
        foreach ($request->data as $d) {
            if($d['name']=='category'){
                DB::table('categories')
                    ->where('id', $request->id)
                    ->update([
                        'name' => $d['value']
                    ]);
            }
            else{
                DB::table('subcategories')
                    ->where('id',$d['name'])
                    ->update([
                        'name'=>$d['value']
                    ]);
            }
        }
        return "Updated category successfully";
    }

    public function delete($id){
        $subcategory_ids=DB::table('subcategories')
            ->where('category_id',$id)
            ->pluck('id')
            ->all();
        DB::table('products')
            ->whereIn('subcategory_id',$subcategory_ids)
            ->delete();
        DB::table('subcategories')
            ->where('category_id',$id)
            ->delete();
        DB::table('categories')
            ->where('id',$id)
            ->delete();
        return "Deleted category successfully";
    }
}
