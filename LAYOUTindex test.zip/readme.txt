Do the followings before run the project.

npm install in frontend project
composer update in backend project
