import './App.css';
import {
	BrowserRouter,
	Switch,
	Routes,
	Route,
	Link
  } from "react-router-dom";
import CreateCategories from './components/categories/Create';
import ViewCategories from './components/categories/View';
import CreateProducts from './components/products/Create';
import ViewProducts from './components/products/View';
import UpdateCategory from './components/categories/Update';
import UpdateProduct from './components/products/Update';
import Home from './components/Home';
import Navbar from './components/Navbar';

function App() {
  return (
    <div className="App">
		<Navbar/>
		<BrowserRouter>
                <Routes>
                    <Route path='/' element={<Home/>}/>
                    <Route path='/create_categories' element={<CreateCategories/>}/>
                    <Route path='/view_categories' element={<ViewCategories/>}/>
                    <Route path='/create_products' element={<CreateProducts/>}/>
					<Route path='/view_products' element={<ViewProducts/>}/>
					<Route path='/update_category/:id' element={<UpdateCategory/>}/>
					<Route path='/update_product/:id' element={<UpdateProduct/>}/>
                </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
