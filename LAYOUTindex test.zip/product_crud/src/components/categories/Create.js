import React from 'react';
import {useState} from 'react';
import axios from 'axios';

export default function Create() {
    const [category, setCategory] = useState('');
    const [subcategories, setSubcategories] = useState('');
    const [messageShow, setMessageShow] = useState(null);
    const [message, setMessage] = useState('');
    const [color, setColor] = useState('');
    const handleCategory = (e) => {
        setCategory(e.target.value);
    }
    const handleSubcategory = (e) => {
        setSubcategories(e.target.value);
    }
    const submit = (e) => {
        if(category=='' || subcategories==''){
            setColor("red");
            setMessage("Fill all details!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
        }
        else{
            axios.post('http://localhost:8000/api/createCategories', {
            name: category,
            subcategories: subcategories,
            })
            .then(result => {
                setColor("#46b800");
                setMessage("Created a new category successfully!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                console.log(result);
                setCategory("");
                setSubcategories("");
            })
            .catch(error => {
                setColor("red");
                setMessage("Error!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                console.log(error);
            });
        }
        
    }
    const Results = () => (
        <h4 id="results" className="search-results" style={{color:color}}>
          {message}
        </h4>
      )
  return (
    <div>
            <h1>Create Categories</h1>
            <div class="col-4" style={{margin: "auto", textAlign: 'left'}}>
                <form>
                { messageShow ? <Results /> : null }
                    <div class="mb-3">
                        <label class="form-label">Category Name:</label>
                        <input type="text" class="form-control" id="category" aria-describedby="emailHelp" value={category} onChange={handleCategory}/>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subcategories:</label>
                        <textarea class="form-control" id="subcategories" aria-describedby="emailHelp" placeholder="Enter subcategory names separated by comas" value={subcategories} onChange={handleSubcategory}></textarea>
                    </div>
                </form>
                <button type="submit" onClick={submit} class="btn btn-primary">Submit</button>
            </div>
    </div>
  )
}
