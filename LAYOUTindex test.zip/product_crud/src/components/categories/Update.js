import React from 'react';
import {
	useParams 
  } from "react-router-dom";
import {useState} from 'react';
import axios from 'axios';
import {  useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Update() {
    const navigate = useNavigate();
    let { id } = useParams();
    const [data, setData] = useState([]);
    const [x, setX] = useState(0);
    const [messageShow, setMessageShow] = useState(null);
    const [message, setMessage] = useState('');
    const [color, setColor] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        let ar=[];
        for (let index = 0; index < e.target.length; index++) {
            ar.push({
                name:e.target[index].id,
                value:e.target[index].value
            });
        }
        axios.put('http://localhost:8000/api/updateCategories',{
            data:ar,
            id:id
        })
        .then(result => {
            setColor("#46b800");
            setMessage("Updated category successfully!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
            setTimeout(function() {
                navigate("/view_categories");
            }.bind(this), 2000);
            console.log(result);
        })
        .catch(error => {
            setColor("red");
            setMessage("Error!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
            console.log(error);
        });
    }
    useEffect(() => {
        (async () => {
          const result = await axios('http://localhost:8000/api/getCategory/'+id);
          setData(result.data);
        })();
      }, [x]);
    
    let formData=data.map((item)=>{
        let subcats=item.subcategories.map((i)=>{
            return (
                <div class="mb-3">
                        <input type="text" class="form-control" aria-describedby="emailHelp" id={i.id} defaultValue={i.name}/>
                </div>
            )
        });
        return (
            <div>
                <div class="mb-3">
                    <label class="form-label">Category Name:</label>
                    <input type="text" class="form-control" id="category" aria-describedby="emailHelp" defaultValue={item.name}/>
                </div>
                <div class="mb-3">
                    <label class="form-label">Subcategories:</label>
                    {subcats}
                </div>
            </div>
        )
    })
    const Results = () => (
        <h4 id="results" className="search-results" style={{color:color}}>
          {message}
        </h4>
      )
    
  return (
    <div>
        <h1>Update Category</h1>
            <div class="col-4" style={{margin: "auto", textAlign: 'left'}}>
                <form onSubmit={handleSubmit}>
                { messageShow ? <Results /> : null }
                    {formData}
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
    </div>
  )
}
