import React from 'react';
import {
	useParams 
  } from "react-router-dom";
import {useState} from 'react';
import axios from 'axios';
import {  useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Update() {
    const navigate = useNavigate();
    let { id } = useParams();
    const [data, setData] = useState([]);
    const [data1, setData1] = useState([]);
    const [x, setX] = useState(0);
    const [messageShow, setMessageShow] = useState(null);
    const [message, setMessage] = useState('');
    const [color, setColor] = useState('');
    useEffect(() => {
        (async () => {
          
          const result = await axios("http://localhost:8000/api/getSubategories");
          setData1(result.data);
        })();
      }, [x]);

    useEffect(() => {
    (async () => {
        const result = await axios('http://localhost:8000/api/getProduct/'+id);
        setData(result.data);
    })();
    }, [x]);

    const handleSubmit = (e) => {
        e.preventDefault();
        let ar=[];
        for (let index = 0; index < e.target.length; index++) {
            ar.push({
                name:e.target[index].id,
                value:e.target[index].value
            });
        }
        axios.put('http://localhost:8000/api/updateProduct',{
            data:ar,
            id:id
        })
        .then(result => {
            setColor("#46b800");
            setMessage("Updated product successfully!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
            setTimeout(function() {
                navigate("/view_products");
            }.bind(this), 2000);
            console.log(result);
        })
        .catch(error => {
            setColor("red");
            setMessage("Error!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
            console.log(error);
        });
    }

      let subcategories=data1.map((item)=>{
        return (
            <option value={item.id}>{item.name+"["+item.category+"]"}</option>
        )
    })
    
    let formData=data.map((item)=>{
        return (
            <div>
                <div class="mb-3">
                    <label class="form-label">Product Name:</label>
                    <input type="text" class="form-control" id="product" aria-describedby="emailHelp" defaultValue={item.name}/>
                </div>
                <div class="mb-3">
                    <label class="form-label">Subcategory:</label>
                    <select class="form-select" aria-label="Default select example" id="subcategory_id" defaultValue={item.subcategory_id}>
                            <option disabled selected value="">Select subcategory</option>
                            {subcategories}
                    </select>
                </div>
            </div>
        )
    })

    const Results = () => (
        <h4 id="results" className="search-results" style={{color:color}}>
          {message}
        </h4>
      )
    
  return (
    <div>
        <h1>Update Product</h1>
            <div class="col-4" style={{margin: "auto", textAlign: 'left'}}>
                <form onSubmit={handleSubmit}>
                { messageShow ? <Results /> : null }
                    {formData}
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
    </div>
  )
}
