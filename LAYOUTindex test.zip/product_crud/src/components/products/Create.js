import React from 'react';
import {useState} from 'react';
import axios from 'axios';
import {  useEffect } from "react";

export default function Create() {
    const [data, setData] = useState([]);
    const [name, setName] = useState('');
    const [subcategory, setSubcategory] = useState('');
    const [messageShow, setMessageShow] = useState(null);
    const [message, setMessage] = useState('');
    const [color, setColor] = useState('');
    const [x, setX] = useState(0);
    const handleSubcategory = (e) => {
        setSubcategory(e.target.value);
    }
    const handleName = (e) => {
        setName(e.target.value);
    }
    useEffect(() => {
        (async () => {
          const result = await axios("http://localhost:8000/api/getSubategories");
          setData(result.data);
        })();
      }, [x]);

    
      const submit = (e) => {
        if(name=='' || subcategory==''){
            setColor("red");
            setMessage("Fill all details!");
            setMessageShow(true);
            setTimeout(function() {
                setMessageShow(false);
            }.bind(this), 2000);
        }
        else{
            axios.post('http://localhost:8000/api/createProduct', {
                name: name,
                subcategory: subcategory
            })
            .then(result => {
                setColor("#46b800");
                setMessage("Created a new product successfully!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                console.log(result);
                setName("");
                setSubcategory("");
            })
            .catch(error => {
                setColor("red");
                setMessage("Error!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                console.log(error);
            });
        }
        
    }
    const Results = () => (
        <h4 id="results" className="search-results" style={{color:color}}>
          {message}
        </h4>
      )

    let subcategories=data.map((item)=>{
        return (
            <option value={item.id}>{item.name+"["+item.category+"]"}</option>
        )
    })
  return (
    <div>
        <h1>Create Products</h1>
            <div class="col-4" style={{margin: "auto", textAlign: 'left'}}>
                <form>
                { messageShow ? <Results /> : null }
                    <div class="mb-3">
                        <label class="form-label">Product Name:</label>
                        <input type="text" class="form-control" id="category" value={name} onChange={handleName} aria-describedby="emailHelp"/>
                    
                    </div>
                    <label class="form-label">Select subcategory:</label>
                    <select class="form-select" aria-label="Default select example" value={subcategory} onChange={handleSubcategory} >
                            <option disabled selected value="">Select subcategory</option>
                            {subcategories}
                    </select> 
                <br></br> 

                </form>
                
                <button type="submit" onClick={submit} class="btn btn-primary">Submit</button>
            </div>
    </div>
  )
}
