import React from 'react';

import {useState} from 'react';
import axios from 'axios';
import {  useEffect } from "react";

export default function () {
    const [data, setData] = useState([]);
    const [messageShow, setMessageShow] = useState(null);
    const [message, setMessage] = useState('');
    const [color, setColor] = useState('');
    const [x, setX] = useState(0);
    useEffect(() => {
        (async () => {
          const result = await axios("http://localhost:8000/api/getProducts");
          setData(result.data);
        })();
      }, [x]);

    const destroy = (id) => (event) => {
            axios.delete('http://localhost:8000/api/deleteProduct/'+id)
            .then(result => {
                setColor("#46b800");
                setMessage("Deleted category successfully!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                setTimeout(function() {
                    window.location.reload();
                }.bind(this), 2000);
                console.log(result);
            })
            .catch(error => {
                setColor("red");
                setMessage("Error!");
                setMessageShow(true);
                setTimeout(function() {
                    setMessageShow(false);
                }.bind(this), 2000);
                console.log(error);
            });
        
    }

    let tableData=data.map((item)=>{
        return (
            <tr>
                <td>{item.name}</td>
                <td>{item.subcategory}</td>
                <td><a href={"update_product/"+item.pro_id} class="btn btn-primary">Update</a></td>
                <td><button type="button" onClick={destroy(item.pro_id)} class="btn btn-danger">Delete</button></td>
            </tr>
        )
    });

    const Results = () => (
        <h4 id="results" className="search-results" style={{color:color}}>
          {message}
        </h4>
      )
  return (
    <div>
        <h1>View Products</h1>
        <div class="col-5" style={{margin: "auto", textAlign: 'left'}}>
            { messageShow ? <Results /> : null }
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Subcategory</th>
                        <th scope="col">Update</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {tableData}
                </tbody>
            </table>
        </div>
    </div>
  )
}
